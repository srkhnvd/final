$(document).ready(function(){
  $("#texx").click(function(){
    $("#tex").slideToggle("slow");
  });
});
